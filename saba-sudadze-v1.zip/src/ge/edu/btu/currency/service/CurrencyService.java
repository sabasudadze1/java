package ge.edu.btu.currency.service;

public interface CurrencyService {
	public int convertAmount(int money);
	public void setExchangeRate(int eRate);
}
